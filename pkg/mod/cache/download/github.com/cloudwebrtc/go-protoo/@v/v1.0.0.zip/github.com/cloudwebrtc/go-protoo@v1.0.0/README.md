# go-protoo

## How to test.
### Run go-protoo-server.
```
git clone https://github.com/cloudwebrtc/go-protoo
cd go-protoo/examples/go
go run server/main.go
```
### Golang client test.
```
cd go-protoo/examples/go
go run client/main.go
```
### JS client test.
```
cd go-protoo/example/js
npm i
npm start
```
### Dart client test.
```
cd go-protoo/example/dart
pub get
dart protoo_dart_client_test.dart
