A sample command-line application.

## Usage

```
pub get
dart protoo_dart_client_test.dart 
```
